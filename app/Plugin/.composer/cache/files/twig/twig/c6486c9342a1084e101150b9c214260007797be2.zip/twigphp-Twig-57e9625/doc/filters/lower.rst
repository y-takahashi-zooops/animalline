``lower``
=========

The ``lower`` filter converts a value to lowercase:

.. code-block:: twig

    {{ 'WELCOME'|lower }}

    {# outputs 'welcome' #}

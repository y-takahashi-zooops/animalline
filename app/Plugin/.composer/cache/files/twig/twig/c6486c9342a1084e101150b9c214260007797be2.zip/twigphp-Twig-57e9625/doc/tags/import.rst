``import``
==========

The ``import`` tag imports :doc:`macro<../tags/macro>` names in a local
variable. The tag is documented in detail in the documentation for the
:doc:`macro<../tags/macro>` tag.
